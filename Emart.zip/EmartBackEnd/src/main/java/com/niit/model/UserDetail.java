package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Table(name="userdetail")
@Entity
public class UserDetail 
{  @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   int userId;
   String username;
   String password;
   String customerName;
   String mobileno;
   String mailid;
   String role;
   String enabled;	

  
   public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

public String getMobileno() {
	return mobileno;
}

public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}

public String getUsername() 
{
	return username;
}
   
public void setUsername(String username) 
{
	this.username = username;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getCustomerName()
{
	return customerName;
}

public void setCustomerName(String customerName)
{
	this.customerName = customerName;
}
public String getMailid() {
	return mailid;
}

public void setMailid(String mailid)
{
	this.mailid = mailid;
}

public String getRole() 
{
	return role;
}

public void setRole(String role) 
{
	this.role = role;
}

public String getEnabled()
{
	return enabled;
}

public void setEnabled(String enabled)
{
	this.enabled = enabled;
}

}
